import "./App.css";
import React from "react";
import Login from "./components/login/login";
import ForgotPassword from "./components/forgot_pass/Forgot_pass";
import { Authlogout } from "./components/Logout/Authlogout";
import { UserProvider } from "./components/Userdetails";
import Wrapper from "./components/dashboard/Wrapper";
import { BrowserRouter, Route, Routes } from "react-router-dom";

function App() {
  return (
    <>
      <BrowserRouter>
        <UserProvider>
          <Authlogout>
            <Routes>
              <Route exact path="/" element={<Login />} />
              <Route exact path="/Forgot" element={<ForgotPassword />} />
              <Route path="/Details/*" element={<Wrapper />} />
            </Routes>
          </Authlogout>
        </UserProvider>
      </BrowserRouter>
    </>
  );
}

export default App;
