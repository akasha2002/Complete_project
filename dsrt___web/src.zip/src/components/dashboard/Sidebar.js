import React, { useState, useEffect } from 'react'
import './dashboard.css';
import { Link } from 'react-router-dom';
import { useAuth } from '../Logout/Authlogout';
import { useUserDetails } from '../Userdetails';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { library } from '@fortawesome/fontawesome-svg-core';
import { fas } from '@fortawesome/free-solid-svg-icons';

library.add(fas);

const Sidebar = (props, ref) => {
    const { handleLogout } = useAuth();
    const { userType, userName } = useUserDetails();
    
    
    const [activeLink, setActiveLink] = useState('');

    useEffect(() => {
        if (userType === 's') {
            setActiveLink('Student Dashboard'); // Set activeLink directly when setting currentHeading
        } else if (userType === 't') {
            setActiveLink('Staff Dashboard'); // Set activeLink directly when setting currentHeading
        }
    }, [userType]);

    const handleLinkClick = (heading) => {
        setActiveLink(heading);
        props.handleLinkClick(heading);
    };
    
    return (
        <>
            <div className={`bg-white`} id="sidebar-wrapper" ref={ref}>
                <div className="sidebar-heading text-center py-4 primary-text fs-4 fw-bold text-uppercase border-bottom">
                    <img
                        src="https://www.fxschool.ac.in/cs-content/themes/fxcbse/assets/img/FX_LOGO.png"
                        alt="FX School Logo"
                        className="me-2"
                        style={{ width: '180px', height: '50px' }} // Adjust the width and height as needed
                    /></div>
                <div className="list-group list-group-flush my-3">
                    {userType === 's' && (
                        <>
                            <Link
                                to="student/Student_Dashboard"
                                onClick={() => handleLinkClick('Student Dashboard')}
                                className={`list-group-item list-group-item-action bg-transparent second-text fw-bold ${activeLink === 'Student Dashboard' ? 'active' : ''}`}
                            >
                                <i className="fas fa-user-graduate me-2"></i>Student Dashboard
                            </Link>
                            <Link
                                to="student/Student_Assigned_work"
                                onClick={() => handleLinkClick('Assigned work')}
                                className={`list-group-item list-group-item-action bg-transparent second-text fw-bold ${activeLink === 'Assigned work' ? 'active' : ''}`}
                            >
                                <i className="fas fa-tasks me-2"></i>Assigned work
                            </Link>
                            <Link
                                to="student/Student_Completed_work"
                                onClick={() => handleLinkClick('Completed work')}
                                className={`list-group-item list-group-item-action bg-transparent second-text fw-bold ${activeLink === 'Completed work' ? 'active' : ''}`}
                            >
                                <i className="fas fa-check-circle me-2"></i>Completed work
                            </Link>
                            <Link
                                to="student/Student_Reward"
                                onClick={() => handleLinkClick('Rewards')}
                                className={`list-group-item list-group-item-action bg-transparent second-text fw-bold ${activeLink === 'Rewards' ? 'active' : ''}`}
                            >
                                <i className="fas fa-gift me-2"></i>Rewards
                            </Link>
                        </>
                    )}
                    {userType === 't' && (
                        <>
                            <Link
                                to="Staff/Staff_Dashboard"
                                onClick={() => handleLinkClick('Staff Dashboard')}
                                className={`list-group-item list-group-item-action bg-transparent second-text fw-bold ${activeLink === 'Staff Dashboard' ? 'active' : ''}`}
                            >
                                <i className="fas fa-chalkboard-teacher me-2"></i>Staff Dashboard
                            </Link>
                            <Link
                                to="Staff/Staff_Assign_Work"
                                onClick={() => handleLinkClick('Assign Work')}
                                className={`list-group-item list-group-item-action bg-transparent second-text fw-bold ${activeLink === 'Assign Work' ? 'active' : ''}`}
                            >
                                <i className="fas fa-tasks me-2"></i>Assign Work
                            </Link>
                            <Link
                                to="Staff/Staff_Assigned_Work"
                                onClick={() => handleLinkClick('Assigned Work')}
                                className={`list-group-item list-group-item-action bg-transparent second-text fw-bold ${activeLink === 'Assigned Work' ? 'active' : ''}`}
                            >
                                <i className="fas fa-check-square me-2"></i>Assigned Work
                            </Link>
                            <Link
                                to="Staff/Staff_Completed_Work"
                                onClick={() => handleLinkClick('Completed Work')}
                                className={`list-group-item list-group-item-action bg-transparent second-text fw-bold ${activeLink === 'Completed Work' ? 'active' : ''}`}
                            >
                                <i className="fas fa-check-circle me-2"></i>Completed Work
                            </Link>
                        </>
                    )}
                    <Link
                        to="Profile"
                        onClick={() => handleLinkClick('Profile')}
                        className={`list-group-item list-group-item-action bg-transparent second-text fw-bold ${activeLink === 'Profile' ? 'active' : ''}`}
                    >
                        <i className="fas fa-user me-2"></i>Profile
                    </Link>
                    <Link className="list-group-item list-group-item-action bg-transparent text-danger fw-bold cursor-pointer" onClick={handleLogout} style={{ cursor: 'pointer' }}>
                        <i className="fas fa-power-off me-2"></i>Logout</Link>
                </div>
            </div>
        </>
    )
}

export default React.forwardRef(Sidebar)