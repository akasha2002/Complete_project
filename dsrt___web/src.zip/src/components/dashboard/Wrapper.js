import React, { useState, useEffect } from "react";
import "./dashboard.css";
import { Route, Routes, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../Logout/Authlogout";
import { useUserDetails } from "../Userdetails";
import Navbar from "./Navbar";
import Sidebar from "./Sidebar";
import Logout from "./Logout";
import Profile from "../profile/Profile";
import Student_Dashboard from "../Details/student/Student_Dashboard";
import Completed_work from "../Details/student/completed_work";
import Reward from "../Details/student/reward";
import Assigned_work from "../Details/student/assigned_work";
import Staff_Dashboard from "../Details/Staff/Staff_Dashboard"
import Assign_Work from "../Details/Staff/Assign_Work";
import Assigned_Work from "../Details/Staff/Staff_Dashboard"

const Wrapper = (props) => {
  const [isToggled, setIsToggled] = useState(false);
  const [userData, setUserData] = useState(null);
  const { state: dashboardUsername } = useLocation();
  // const userType = props.userType
  const navigate = useNavigate();
  const { handleLogout, showLogoutModal } = useAuth();
  const { userType, userName } = useUserDetails();

  const [currentHeading, setCurrentHeading] = useState('');

  const handleLinkClick = (heading) => {
    setCurrentHeading(heading);
  };

  const handleToggle = () => {
    setIsToggled(!isToggled);
  };

  const handleProfileClick = () => {
    navigate(`Profile`, { state: { username: dashboardUsername } });
  };

  // useEffect(() => {
  //   const fetchUserProfile = async () => {
  //     try {
  //       const response = await fetch("http://localhost:3001/profile/student", {
  //         method: "POST",
  //         headers: {
  //           "Content-Type": "application/json",
  //         },
  //         body: JSON.stringify({ username: dashboardUsername }),
  //       });

  //       if (!response.ok) {
  //         throw new Error("Failed to fetch user profile");
  //       }

  //       const data = await response.json();
  //       setUserData(data);
  //     } catch (error) {
  //       console.error("Error fetching user profile:", error.message);
  //     }
  //   };

  //   if (dashboardUsername) {
  //     fetchUserProfile();
  //   }

  // }, [dashboardUsername]);

  return (
    <>
      <div className={`d-flex ${isToggled ? "toggled" : ""} ${showLogoutModal ? "blur-background" : ""}`} id="wrapper">
        <Sidebar userType={userType} userName={userName}
        //  userType={userType}
          handleLinkClick={handleLinkClick} handleLogout={handleLogout} />
        <div id="page-content-wrapper">
          <Navbar
            userData={userData}
            isToggled={isToggled}
            handleToggle={handleToggle}
            handleLinkClick={handleLinkClick}
            handleProfileClick={handleProfileClick}
            currentHeading={currentHeading}
            handleLogout={handleLogout}
          />
          <Routes>
            <Route path="Profile" element={<Profile  />} />
            <Route path="Student_Dashboard" element={<Student_Dashboard />} />
            <Route path="Completed_work" element={<Completed_work />} />
            <Route path="Reward" element={<Reward />} />
            <Route path="Assigned_work" element={<Assigned_work />} />
            <Route path="Staff_Dashboard" element={<Staff_Dashboard userType={userType} userName={userName} />} />
            <Route path="Assign_Work" element={<Assign_Work />} />
            <Route path="Assigned_Work" element={<Assigned_Work />} />
          </Routes>
        </div>
      </div>
      <Logout></Logout>
    </>
  );
};

export default Wrapper;
