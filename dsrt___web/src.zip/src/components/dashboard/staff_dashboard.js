import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';

export default function Staff_changed_Dashboard(props) {
    const { state: Username } = useLocation();
    const [studentData, setStudentData] = useState([]);
    const [selectedCategory, setSelectedCategory] = useState('All');
    const [selectedStandard, setSelectedStandard] = useState('All');
    const [additionalData, setAdditionalData] = useState([]);
    const [searchKeyword, setSearchKeyword] = useState('');

    useEffect(() => {
        // Fetch data from the API with the username included in the request
        fetch('http://localhost:3001/staff_details/students', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                username: Username
            })
        })
        .then(response => response.json())
        .then(data => {
            // Update studentData state with the fetched data
            setStudentData(data.user);
        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });

        fetch('http://localhost:3001/staff_details', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                username: Username
            })
        })
        .then(response => response.json())
        .then(data => {
            // Update studentData state with the fetched data
            setAdditionalData(data.user);
        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });
    }, [Username]); // Include Username in the dependency array to re-fetch data when it changes

    // Filter students based on selected category and standard
    const filteredStudents = studentData.filter(student => {
        if (selectedCategory !== 'All' && student.category !== selectedCategory) {
            return false;
        }
        if (selectedStandard !== 'All' && student.Student_standard !== selectedStandard) {
            return false;
        }
        if (searchKeyword && !student.student_name.toLowerCase().includes(searchKeyword.toLowerCase())) {
            return false;
        }
        return true;
    });

    // Get unique categories and standards from the student data
    const categories = [...new Set(studentData.map(student => student.category))];
    const standards = [...new Set(studentData.map(student => student.Student_standard))];

    return (
        <>
            <div className="container-fluid px-2">
                {/* Dropdown button to select category */}
                {/* <h4>Staff Name :{additionalData.staff_name}</h4> */}
                <div className="dropdown mb-3">
                    {/* Dropdown button code... */}
                </div>
                {/* Toggle button to select standard */}
                <div className="btn-group mb-3" role="group" aria-label="Basic example">
                    {/* Toggle button group code... */}
                </div>
                {/* Search button */}
                <div className="input-group mb-3">
                    <input
                        type="text"
                        className="form-control"
                        placeholder="Search by student name..."
                        value={searchKeyword}
                        onChange={(e) => setSearchKeyword(e.target.value)}
                    />
                    <button
                        className="btn btn-primary"
                        type="button"
                        onClick={() => setSearchKeyword('')}
                    >
                        Clear
                    </button>
                </div>
                {/* Your other JSX code */}
                <div className="row my-5">
                    <div className="col">
                        <table className="table table-bordered table-striped">
                            <thead className="bg-primary text-white">
                                <tr>
                                    <th>Student ID</th>
                                    <th>Student Name</th>
                                    <th>Standard</th>
                                    <th>Category</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredStudents.map((student, index) => (
                                    <tr key={index}>
                                        <td>{student.student_id}</td>
                                        <td>{student.student_name}</td>
                                        <td>{student.Student_standard}</td>
                                        <td>{student.category}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </>
    );
}
