import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { useUserDetails } from "../Userdetails";

const Profile = () => {
  const { state } = useLocation();
  const { userType, userName } = useUserDetails();
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
        const response = await fetch("http://localhost:3001/profile/student", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ username: userName }),
        });

        if (!response.ok) {
          throw new Error("Failed to fetch user profile");
        }

        const data = await response.json();
        setUserData(data);
      } catch (error) {
        console.error("Error fetching user profile:", error.message);
      }
    };

    const fetchUserProfile_2 = async () => {
      try {
        const response = await fetch("http://localhost:3001/profile/staff", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ username: userName }),
        });

        if (!response.ok) {
          throw new Error("Failed to fetch user profile staff");
        }

        const data = await response.json();
        setUserData(data);
      } catch (error) {
        console.error("Error fetching user profile staff:", error.message);
      }
    };

    if (userType === "s") {
      fetchUserProfile();
    }
    if (userType === "t") {
      fetchUserProfile_2();
    }
  }, [userName, userType]);

  return (
    <>
      <section style={{ backgroundColor: "#eee" }}>
        <div className="container py-4">
          <div className="row">
            <div className="col-lg-13">
              <div className="card mb-4" style={{ height: "180px" }}>
                <div className="card-body text-center">
                  {/* <img
                    src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava3.webp"
                    alt="avatar"
                    className="rounded-circle img-fluid"
                    style={{
                      width: "130px",
                      position: "absolute",
                      left: "10%",
                      transform: "translateX(-50%)",
                      top: "13px",
                    }}
                  /> */}
                  <img
                    src={`http://localhost:3001/avatars/${userData?.image_link}`}
                    alt="avatarrr"
                    className="rounded-circle img-fluid"
                    style={{
                      width: "130px",
                      position: "absolute",
                      left: "10%",
                      transform: "translateX(-50%)",
                      top: "13px",
                    }}
                  />
                  <div
                    className="my-3.5"
                    style={{ marginTop: "28px", marginLeft: "-400px" }}
                  >
                    {userName ? (
                      <h2>Welcome, {userData?.student_name}!</h2>
                    ) : (
                      <p>No username available</p>
                    )}
                  </div>
                  {/* <h5 className="my-3"></h5> */}
                  <p
                    className="text-muted mb-1"
                    style={{ marginLeft: "-400px" }}
                  >
                    {userData?.Student_standard}
                  </p>
                  <p
                    className="text-muted mb-4"
                    style={{ marginLeft: "-400px" }}
                  >
                    {userData?.email}
                  </p>
                </div>
              </div>
            </div>
            <div className="row">
              <div className="col-md-6">
                <div className="card mb-4 mb-md-0">
                  <div className="card-body">
                    <p className="mb-4">
                      <span className="text-primary font-italic me-1">
                        Personal Details
                      </span>
                    </p>
                    <hr />
                    <div className="row">
                      <div className="col-sm-3">
                        <p className="mb-0">Full Name</p>
                      </div>
                      <div className="col-sm-9">
                        <p className="text-muted mb-0">
                          {userData?.student_name}
                        </p>
                      </div>
                    </div>
                    <hr />
                    <div className="row">
                      <div className="col-sm-3">
                        <p className="mb-0">Date Of Birth</p>
                      </div>
                      <div className="col-sm-9">
                        <p className="text-muted mb-0">{userData?.email}</p>
                      </div>
                    </div>
                    <hr />
                    <div className="row">
                      <div className="col-sm-3">
                        <p className="mb-0">Blood Group</p>
                      </div>
                      <div className="col-sm-9">
                        <p className="text-muted mb-0">{userData?.email}</p>
                      </div>
                    </div>
                    <hr />
                    <div className="row">
                      <div className="col-sm-3">
                        <p className="mb-0">Gender</p>
                      </div>
                      <div className="col-sm-9">
                        <p className="text-muted mb-0">{userData?.email}</p>
                      </div>
                    </div>
                    <hr />
                    <div className="row">
                      <div className="col-sm-3">
                        <p className="mb-0">Caste</p>
                      </div>
                      <div className="col-sm-9">
                        <p className="text-muted mb-0">{userData?.email}</p>
                      </div>
                    </div>
                    <hr />
                    <div className="row">
                      <div className="col-sm-3">
                        <p className="mb-0">Religion</p>
                      </div>
                      <div className="col-sm-9">
                        <p className="text-muted mb-0">{userData?.email}</p>
                      </div>
                    </div>
                    <hr />
                    <div className="row">
                      <div className="col-sm-3">
                        <p className="mb-0">Email</p>
                      </div>
                      <div className="col-sm-9">
                        <p className="text-muted mb-0">{userData?.email}</p>
                      </div>
                    </div>
                    <hr />
                    <div className="row">
                      <div className="col-sm-3">
                        <p className="mb-0">Father's Mobile Number</p>
                      </div>
                      <div className="col-sm-9">
                        <p className="text-muted mb-0">
                          {userData?.student_mobile_no}
                        </p>
                      </div>
                    </div>
                    <hr />
                    <div className="row">
                      <div className="col-sm-3">
                        <p className="mb-0">Mother's Mobile Number</p>
                      </div>
                      <div className="col-sm-9">
                        <p className="text-muted mb-0">
                          {userData?.student_mobile_no}
                        </p>
                      </div>
                    </div>
                    <hr />
                    <div className="row">
                      <div className="col-sm-3">
                        <p className="mb-0">Communication Address</p>
                      </div>
                      <div className="col-sm-9">
                        <p className="text-muted mb-0">
                          {userData?.address_student_door_no},
                          {userData?.address_student_street},
                          {userData?.address_student_district},
                          {userData?.address_student_state}
                        </p>
                      </div>
                    </div>
                    <hr />
                    <div className="row">
                      <div className="col-sm-3">
                        <p className="mb-0">Permanent Address</p>
                      </div>
                      <div className="col-sm-9">
                        <p className="text-muted mb-0">
                          {userData?.address_student_door_no},
                          {userData?.address_student_street},
                          {userData?.address_student_district},
                          {userData?.address_student_state}
                        </p>
                      </div>
                    </div>
                    <hr />
                  </div>
                </div>
              </div>
              <div className="col-md-6">
                <div className="card mb-4 mb-md-4">
                  <div className="card-body">
                    <p className="mb-4">
                      <span className="text-primary font-italic me-1">
                        Academic Details
                      </span>{" "}
                    </p>

                    <hr></hr>
                    <div className="row">
                      <div className="col-sm-3">
                        <p className="mb-0">Standard</p>
                      </div>
                      <div className="col-sm-9">
                        <p className="text-muted mb-0">
                          {userData?.address_student_door_no},
                          {userData?.address_student_street},
                          {userData?.address_student_district},
                          {userData?.address_student_state}
                        </p>
                      </div>
                    </div>
                    <hr />
                    <div className="row">
                      <div className="col-sm-3">
                        <p className="mb-0">Batch</p>
                      </div>
                      <div className="col-sm-9">
                        <p className="text-muted mb-0">
                          {userData?.address_student_door_no},
                          {userData?.address_student_street},
                          {userData?.address_student_district},
                          {userData?.address_student_state}
                        </p>
                      </div>
                    </div>
                    <hr />
                    <div className="row">
                      <div className="col-sm-3">
                        <p className="mb-0">Status</p>
                      </div>
                      <div className="col-sm-9">
                        <p className="text-muted mb-0">
                          {userData?.address_student_door_no},
                          {userData?.address_student_street},
                          {userData?.address_student_district},
                          {userData?.address_student_state}
                        </p>
                      </div>
                    </div>
                    <hr />
                    <div className="row">
                      <div className="col-sm-3">
                        <p className="mb-0">Current Subjects</p>
                      </div>
                      <div className="col-sm-9">
                        <p className="text-muted mb-0">
                          {userData?.address_student_door_no},
                          {userData?.address_student_street},
                          {userData?.address_student_district},
                          {userData?.address_student_state}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-12">
                  <div className="card mb-4 mb-md-4">
                    {" "}
                    {/* Add margin-top */}
                    <div className="card-body">
                      <p className="mb-4">
                        <span className="text-primary font-italic me-1">
                          Rewards Points
                        </span>{" "}
                      </p>

                      <hr></hr>
                      <div className="row">
                        <div className="col-sm-3">
                          <p className="mb-0">Tamil</p>
                        </div>
                        <div className="col-sm-9">
                          <p className="text-muted mb-0">
                            {userData?.address_student_door_no},
                            {userData?.address_student_street},
                            {userData?.address_student_district},
                            {userData?.address_student_state}
                          </p>
                        </div>
                      </div>
                      <hr />
                      <div className="row">
                        <div className="col-sm-3">
                          <p className="mb-0">English</p>
                        </div>
                        <div className="col-sm-9">
                          <p className="text-muted mb-0">
                            {userData?.address_student_door_no},
                            {userData?.address_student_street},
                            {userData?.address_student_district},
                            {userData?.address_student_state}
                          </p>
                        </div>
                      </div>
                      <hr />
                      <div className="row">
                        <div className="col-sm-3">
                          <p className="mb-0">Maths</p>
                        </div>
                        <div className="col-sm-9">
                          <p className="text-muted mb-0">
                            {userData?.address_student_door_no},
                            {userData?.address_student_street},
                            {userData?.address_student_district},
                            {userData?.address_student_state}
                          </p>
                        </div>
                      </div>
                      <hr />
                      <div className="row">
                        <div className="col-sm-3">
                          <p className="mb-0">Social</p>
                        </div>
                        <div className="col-sm-9">
                          <p className="text-muted mb-0">
                            {userData?.address_student_door_no},
                            {userData?.address_student_street},
                            {userData?.address_student_district},
                            {userData?.address_student_state}
                          </p>
                        </div>
                      </div>
                      <hr />
                      <div className="row">
                        <div className="col-sm-3">
                          <p className="mb-0">Science</p>
                        </div>
                        <div className="col-sm-9">
                          <p className="text-muted mb-0">
                            {userData?.address_student_door_no},
                            {userData?.address_student_street},
                            {userData?.address_student_district},
                            {userData?.address_student_state}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Profile;

// import React, { useState, useEffect } from 'react';
// import { useLocation } from 'react-router-dom';
// import { useUserDetails } from '../Userdetails';
// const Profile = () => {
//   const { state } = useLocation();
//   const { userType, userName } = useUserDetails();
//   // console.log("profile username: ",userName)
//   // const username = state ? state.username : null;
//   // console.log(username)

//   const [userData, setuserData] = useState(null);

//   useEffect(() => {
//     const fetchUserProfile = async () => {
//       try {
//         // const response = await fetch('http://192.168.1.2:3001/profile/student', {
//           const response = await fetch('http://localhost:3001/profile/student', {
//           method: 'POST',
//           headers: {
//             'Content-Type': 'application/json',
//           },
//           body: JSON.stringify({ username: userName }),
//         });

//         if (!response.ok) {
//           throw new Error('Failed to fetch user profile');
//         }

//         const data = await response.json();
//         setuserData(data);
//       } catch (error) {
//         console.error('Error fetching user profile:', error.message);
//       }
//     };
//     const fetchUserProfile_2 = async () => {

//       try {
//         // if(userType === 's'){
//         // const response = await fetch("http://192.168.1.2:3001/profile/staff", {
//         const response = await fetch("http://localhost:3001/profile/staff", {
//           method: "POST",
//           headers: {
//             "Content-Type": "application/json",
//           },
//           body: JSON.stringify({ username: userName }),
//         });
//       // }
//         // if(userType === 't'){
//         //   const response = await fetch("http://localhost:3001/profile/student", {
//         //   method: "POST",
//         //   headers: {
//         //     "Content-Type": "application/json",
//         //   },
//         //   body: JSON.stringify({ username: userName }),
//         // });
//         // }

//         if (!response.ok) {
//           throw new Error("Failed to fetch user profile student");
//         }

//         const data = await response.json();
//             setuserData(data);
//         // setLoading(false);
//       } catch (error) {
//         console.error("Error fetching user profile student :", error.message);
//         // setLoading(false);
//       }
//     };

//     if (userType === 's') {
//       fetchUserProfile();
//     }
//     if (userType === 't') {
//       fetchUserProfile_2();
//     }
//   }, [userName]);

//   return (
//     <>
//       <section style={{ backgroundColor: '#eee' }}>
//         <div className="container py-5">
//           <div className="row">
//             <div className="col-lg-4">
//               <div className="card mb-4">
//                 <div className="card-body text-center">
//                 <img src={`http://localhost:3001/avatars/${userData?.image_link}`} alt="avatarrr" className="rounded-circle img-fluid" style={{ width: '150px' }} />

//                   <div className="my-3">{userName ? <h2>Welcome, {userData?.student_name}!</h2> : <p>No username available</p>}</div>

//                   <p className="text-muted mb-1">{userData?.Student_standard}</p>
//                   <p className="text-muted mb-4">{userData?.email}</p>

//                 </div>
//               </div>

//             </div>
//             <div className="col-lg-8">
//               <div className="card mb-4">
//                 <div className="card-body">
//                   <div className="row">
//                     <div className="col-sm-3">
//                       <p className="mb-0">Full Name</p>
//                     </div>
//                     <div className="col-sm-9">
//                       <p className="text-muted mb-0">{userData?.student_name}</p>
//                     </div>
//                   </div>
//                   <hr />
//                   <div className="row">
//                     <div className="col-sm-3">
//                       <p className="mb-0">Email</p>
//                     </div>
//                     <div className="col-sm-9">
//                       <p className="text-muted mb-0">{userData?.email}</p>
//                     </div>
//                   </div>
//                   <hr />
//                   <div className="row">
//                     <div className="col-sm-3">
//                       <p className="mb-0">Phone</p>
//                     </div>
//                     <div className="col-sm-9">
//                       <p className="text-muted mb-0">(097) 234-5678</p>
//                     </div>
//                   </div>
//                   <hr />
//                   <div className="row">
//                     <div className="col-sm-3">
//                       <p className="mb-0">Mobile</p>
//                     </div>
//                     <div className="col-sm-9">
//                       <p className="text-muted mb-0">{userData?.student_mobile_no}</p>
//                     </div>
//                   </div>
//                   <hr />
//                   <div className="row">
//                     <div className="col-sm-3">
//                       <p className="mb-0">Address</p>
//                     </div>
//                     <div className="col-sm-9">
//                       <p className="text-muted mb-0">{userData?.address_student_door_no},{userData?.address_student_street},{userData?.address_student_district},{userData?.address_student_state}</p>
//                     </div>
//                   </div>
//                 </div>
//               </div>

//             </div>
//           </div>
//         </div>
//       </section>
//     </>
//   );
// };

// export default Profile;
